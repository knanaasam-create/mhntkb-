<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Job,Bid};

class BidController extends Controller
{
    public function store(Request $req, Job $job)
    {
        $this->authorize('professional');
        abort_if($job->status !== 'open', 422, 'الطلب غير متاح');
        $data = $req->validate([
            'price'=>'required|integer|min:1',
            'note'=>'nullable|string'
        ]);
        $bid = Bid::updateOrCreate(
            ['job_id'=>$job->id,'professional_id'=>auth()->user()->professional->id],
            $data
        );
        return back()->with('ok','تم تقديم العرض');
    }

    public function list(Job $job)
    {
        $this->authorize('owns-job',$job);
        $bids = $job->bids()->with('professional.user')->latest()->get();
        return view('bids.index', compact('job','bids'));
    }
}
