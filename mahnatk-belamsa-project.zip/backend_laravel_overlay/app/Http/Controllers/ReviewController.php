<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Contract,Review};

class ReviewController extends Controller
{
    public function store(Request $req, Contract $contract)
    {
        $this->authorize('owns-contract-as-customer',$contract);
        abort_unless($contract->status === 'completed', 422, 'العقد غير مكتمل.');
        $data = $req->validate(['rating'=>'required|integer|min:1|max:5','comment'=>'nullable|string']);
        Review::create($data + ['contract_id'=>$contract->id]);
        return back()->with('ok','شكراً لتقييمك');
    }
}
