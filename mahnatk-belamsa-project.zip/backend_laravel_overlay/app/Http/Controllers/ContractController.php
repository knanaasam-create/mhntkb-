<?php

namespace App\Http\Controllers;

use App\Models\{Bid,Contract};

class ContractController extends Controller
{
    public function accept(Bid $bid)
    {
        $job = $bid->job;
        $this->authorize('owns-job',$job);
        abort_if($job->status !== 'open', 422, 'لا يمكن إتمام القبول');
        $contract = Contract::create([
            'job_id'=>$job->id,
            'bid_id'=>$bid->id,
            'status'=>'active',
            'accepted_at'=>now()
        ]);
        $job->update(['status'=>'in_contract']);
        return redirect()->route('contracts.show',$contract)->with('ok','تم إنشاء العقد');
    }
}
