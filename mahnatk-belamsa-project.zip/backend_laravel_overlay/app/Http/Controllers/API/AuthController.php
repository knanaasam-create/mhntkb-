<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{User,Customer,Professional,Profession};
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register(Request $req){
        $data = $req->validate([
            'name'=>'required|string|max:100',
            'email'=>'required|email|unique:users,email',
            'password'=>'required|string|min:6',
            'role'=>'required|in:Customer,Professional',
            'profession_id'=>'nullable|exists:professions,id'
        ]);
        $user = User::create([
            'name'=>$data['name'],
            'email'=>$data['email'],
            'password'=>Hash::make($data['password'])
        ]);
        $user->assignRole($data['role']);
        if ($data['role']==='Customer'){
            Customer::create(['user_id'=>$user->id]);
        } else {
            Professional::create(['user_id'=>$user->id,'profession_id'=>$data['profession_id'] ?? Profession::first()->id]);
        }
        Auth::login($user);
        return response()->json(['user'=>$user->only('id','name','email'),'roles'=>$user->getRoleNames()],201);
    }

    public function login(Request $req){
        $cred = $req->validate(['email'=>'required|email','password'=>'required']);
        if (!Auth::attempt($cred, true)) {
            throw ValidationException::withMessages(['email'=>'بيانات الدخول غير صحيحة']);
        }
        $user = $req->user();
        return response()->json(['user'=>$user->only('id','name','email'),'roles'=>$user->getRoleNames()]);
    }

    public function logout(Request $req){
        Auth::guard('web')->logout();
        $req->session()->invalidate();
        $req->session()->regenerateToken();
        return response()->json(['ok'=>true]);
    }
}
