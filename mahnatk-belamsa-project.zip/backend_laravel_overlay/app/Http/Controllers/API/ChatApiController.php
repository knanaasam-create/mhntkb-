<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Conversation,Message};
use App\Events\MessageSent;

class ChatApiController extends Controller
{
    public function send(Request $req, Conversation $conversation){
        $this->authorize('in-conversation', $conversation);
        $data = $req->validate(['body'=>'required|string']);
        $msg = $conversation->messages()->create([
            'user_id'=>auth()->id(),
            'body'=>$data['body']
        ]);
        event(new MessageSent($msg));
        return response()->json(['ok'=>true,'message'=>$msg]);
    }
}
