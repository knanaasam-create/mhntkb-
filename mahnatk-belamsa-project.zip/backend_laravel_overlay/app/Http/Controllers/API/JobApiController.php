<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Job,JobImage};

class JobApiController extends Controller
{
    public function index(){
        return Job::with('customer.user')->where('status','open')->latest()->paginate(12);
    }

    public function show(Job $job){
        return $job->load('customer.user','images','bids');
    }

    public function store(Request $req){
        $this->authorize('customer');
        $data = $req->validate([
            'title'=>'required|string|max:150',
            'description'=>'required|string',
            'city'=>'nullable|string',
        ]);
        $job = Job::create([
            'customer_id'=>auth()->user()->customer->id,
            'title'=>$data['title'],
            'description'=>$data['description'],
            'city'=>$data['city'] ?? null,
        ]);
        return response()->json($job, 201);
    }
}
