<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Job,Bid};

class BidApiController extends Controller
{
    public function store(Request $req, Job $job){
        $this->authorize('professional');
        abort_if($job->status !== 'open', 422, 'الطلب غير متاح');
        $data = $req->validate(['price'=>'required|integer|min:1','note'=>'nullable|string']);
        $bid = Bid::updateOrCreate(
            ['job_id'=>$job->id,'professional_id'=>auth()->user()->professional->id],
            $data
        );
        return response()->json($bid, 201);
    }

    public function list(Job $job){
        $this->authorize('owns-job',$job);
        return $job->bids()->with('professional.user')->latest()->get();
    }
}
