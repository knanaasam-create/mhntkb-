<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\{Bid,Contract};

class ContractApiController extends Controller
{
    public function accept(Bid $bid){
        $job = $bid->job;
        $this->authorize('owns-job',$job);
        abort_if($job->status !== 'open', 422, 'لا يمكن إتمام القبول');
        $contract = Contract::create([
            'job_id'=>$job->id,
            'bid_id'=>$bid->id,
            'status'=>'active',
            'accepted_at'=>now()
        ]);
        $job->update(['status'=>'in_contract']);
        return response()->json($contract, 201);
    }

    public function show(Contract $contract){
        return $contract->load('job','bid');
    }
}
