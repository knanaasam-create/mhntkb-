<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Job,JobImage};

class JobController extends Controller
{
    public function index()
    {
        $q = Job::with('customer.user')->where('status','open')->latest()->paginate(12);
        return view('jobs.index', compact('q'));
    }

    public function show(Job $job)
    {
        $job->load('customer.user','images');
        return view('jobs.show', compact('job'));
    }

    public function store(Request $req)
    {
        $this->authorize('customer');
        $data = $req->validate([
            'title'=>'required|string|max:150',
            'description'=>'required|string',
            'city'=>'nullable|string',
            'images.*'=>'image|max:5120'
        ]);
        $job = Job::create([
            'customer_id'=>auth()->user()->customer->id,
            'title'=>$data['title'],
            'description'=>$data['description'],
            'city'=>$data['city'] ?? null,
        ]);
        if ($req->hasFile('images')) {
            foreach($req->file('images') as $img){
                $path = $img->store('jobs','public');
                JobImage::create(['job_id'=>$job->id,'path'=>$path]);
            }
        }
        return back()->with('ok','تم إنشاء الطلب');
    }
}
