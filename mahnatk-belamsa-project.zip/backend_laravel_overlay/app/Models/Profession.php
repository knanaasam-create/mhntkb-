<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Profession extends Model {
    protected $fillable=['name','slug'];
    public function professionals(){ return $this->hasMany(Professional::class); }
}