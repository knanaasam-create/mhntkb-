<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Contract extends Model {
    protected $fillable=['job_id','bid_id','status','accepted_at'];
    protected $casts=['accepted_at'=>'datetime'];
    public function job(){ return $this->belongsTo(Job::class); }
    public function bid(){ return $this->belongsTo(Bid::class); }
}