<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Job extends Model {
    protected $fillable=['customer_id','title','description','city','status'];
    public function customer(){ return $this->belongsTo(Customer::class); }
    public function images(){ return $this->hasMany(JobImage::class); }
    public function bids(){ return $this->hasMany(Bid::class); }
}