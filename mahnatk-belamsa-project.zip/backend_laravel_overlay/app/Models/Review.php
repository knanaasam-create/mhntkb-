<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Review extends Model {
    protected $fillable=['contract_id','rating','comment'];
    public function contract(){ return $this->belongsTo(Contract::class); }
}