<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Conversation extends Model {
    protected $fillable=[];
    public function customer(){ return $this->belongsTo(Customer::class); }
    public function professional(){ return $this->belongsTo(Professional::class); }
    public function messages(){ return $this->hasMany(Message::class); }
}