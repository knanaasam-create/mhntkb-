<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProfessionalResource\Pages;
use App\Models\Professional;
use Filament\Forms;
use Filament\Tables;
use Filament\Resources\Form;
use Filament\Resources\Table;
use Filament\Resources\Resource;

class ProfessionalResource extends Resource
{
    protected static ?string $model = Professional::class;
    protected static ?string $navigationIcon = 'heroicon-o-user-group';
    protected static ?string $navigationLabel = 'المهنيون';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('status')
                ->options(['pending'=>'قيد المراجعة','approved'=>'مقبول','rejected'=>'مرفوض'])
                ->required(),
            Forms\Components\Textarea::make('bio')->rows(4),
            Forms\Components\TextInput::make('city'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('id')->sortable(),
            Tables\Columns\TextColumn::make('user.name')->label('المستخدم')->searchable(),
            Tables\Columns\TextColumn::make('profession.name')->label('المهنة')->searchable(),
            Tables\Columns\BadgeColumn::make('status')
                ->colors(['warning'=>'pending','success'=>'approved','danger'=>'rejected'])
                ->label('الحالة'),
            Tables\Columns\TextColumn::make('created_at')->dateTime(),
        ])->actions([
            Tables\Actions\EditAction::make(),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProfessionals::route('/'),
            'edit' => Pages\EditProfessional::route('/{record}/edit'),
        ];
    }
}
