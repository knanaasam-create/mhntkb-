<?php
namespace App\Filament\Resources\ProfessionalResource\Pages;
use App\Filament\Resources\ProfessionalResource;
use Filament\Resources\Pages\ListRecords;
class ListProfessionals extends ListRecords { protected static string $resource = ProfessionalResource::class; }