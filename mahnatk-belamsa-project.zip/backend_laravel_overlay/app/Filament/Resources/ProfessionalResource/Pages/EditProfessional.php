<?php
namespace App\Filament\Resources\ProfessionalResource\Pages;
use App\Filament\Resources\ProfessionalResource;
use Filament\Resources\Pages\EditRecord;
class EditProfessional extends EditRecord { protected static string $resource = ProfessionalResource::class; }