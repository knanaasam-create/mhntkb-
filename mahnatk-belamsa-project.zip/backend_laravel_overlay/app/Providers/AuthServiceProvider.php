<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use App\Models\{Job,Contract,Conversation};

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
    ];

    public function boot(): void
    {
        Gate::define('customer', fn($user) => $user->hasRole('Customer'));
        Gate::define('professional', fn($user) => $user->hasRole('Professional'));

        Gate::define('owns-job', function($user, Job $job){
            return $user->hasRole('Customer') && optional($user->customer)->id === $job->customer_id;
        });

        Gate::define('in-conversation', function($user, Conversation $c){
            return optional($c->customer)->user_id === $user->id || optional($c->professional)->user_id === $user->id;
        });

        Gate::define('owns-contract-as-customer', function($user, Contract $contract){
            return $user->hasRole('Customer') && optional($contract->job->customer)->user_id === $user->id;
        });
    }
}
