<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(){
        Schema::create('bids', function(Blueprint $table){
            $table->id();
            $table->foreignId('job_id')->constrained()->cascadeOnDelete();
            $table->foreignId('professional_id')->constrained()->cascadeOnDelete();
            $table->integer('price');
            $table->text('note')->nullable();
            $table->timestamps();
            $table->unique(['job_id','professional_id']);
        });
    }
    public function down(){ Schema::dropIfExists('bids'); }
};
