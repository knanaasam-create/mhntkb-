<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(){
        Schema::create('contracts', function(Blueprint $table){
            $table->id();
            $table->foreignId('job_id')->constrained()->cascadeOnDelete();
            $table->foreignId('bid_id')->constrained()->cascadeOnDelete();
            $table->enum('status',['active','completed','cancelled'])->default('active');
            $table->timestamp('accepted_at')->nullable();
            $table->timestamps();
            $table->unique('job_id');
        });
    }
    public function down(){ Schema::dropIfExists('contracts'); }
};
