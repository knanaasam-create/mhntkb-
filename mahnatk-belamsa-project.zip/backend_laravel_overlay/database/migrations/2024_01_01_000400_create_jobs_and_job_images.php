<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(){
        Schema::create('jobs', function(Blueprint $table){
            $table->id();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->string('title');
            $table->text('description');
            $table->string('city')->nullable();
            $table->enum('status',['open','in_contract','completed','cancelled'])->default('open');
            $table->timestamps();
        });
        Schema::create('job_images', function(Blueprint $table){
            $table->id();
            $table->foreignId('job_id')->constrained()->cascadeOnDelete();
            $table->string('path');
            $table->timestamps();
        });
    }
    public function down(){
        Schema::dropIfExists('job_images');
        Schema::dropIfExists('jobs');
    }
};
