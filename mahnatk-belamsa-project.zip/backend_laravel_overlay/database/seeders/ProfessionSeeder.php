<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\Profession;

class ProfessionSeeder extends Seeder
{
    public function run(): void
    {
        foreach (['سباكة','كهرباء','نجارة','دهان','تبريد وتكييف'] as $name) {
            Profession::firstOrCreate(
                ['name'=>$name],
                ['slug'=>Str::slug($name)]
            );
        }
    }
}
