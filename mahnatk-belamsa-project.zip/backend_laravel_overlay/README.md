# مهنتك بلمسة — Laravel MVP Starter (ملفات جاهزة للإسقاط)

هذا الأرشيف يحتوي ملفات **Laravel** الجاهزة لبناء النسخة الأولية (MVP):
- Migrations + Models + Controllers
- Events + Broadcasting + WebSockets
- Gates (صلاحيات) في AuthServiceProvider
- Filament Resources (المهن + اعتماد المهنيين)
- Routes (ويب + قنوات البث)

> **مهم:** هذه ليست مشروع Laravel كامل. قم بإنشاء مشروع جديد ثم انسخ هذه الملفات إلى أماكنها.

---
## 0) إنشاء مشروع Laravel وتثبيت الحزم
```bash
composer create-project laravel/laravel mhnatk-mvp
cd mhnatk-mvp

# المصادقة (Blade) — اختياري لو ستستخدم Vue منفصل
composer require laravel/breeze --dev
php artisan breeze:install blade
npm i && npm run build

# الأدوار والصلاحيات
composer require spatie/laravel-permission

# لوحة المدير Filament
composer require filament/filament:"^3.2"

# مكتبة ملفات (اختياري): 
composer require spatie/laravel-medialibrary:^11.0

# Sanctum للـ API (إن لزم ربط مع Vue)
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"

# WebSockets للمحادثات
composer require beyondcode/laravel-websockets
php artisan vendor:publish --provider="BeyondCode\LaravelWebSockets\WebSocketsServiceProvider"
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
```

## 1) ضبط .env
أضف/عدّل القيم التالية:
```env
APP_NAME="Mahnatk MVP"
APP_URL=http://localhost

DB_DATABASE=mahnatk
DB_USERNAME=root
DB_PASSWORD=

BROADCAST_DRIVER=pusher
QUEUE_CONNECTION=database

PUSHER_APP_ID=local
PUSHER_APP_KEY=local
PUSHER_APP_SECRET=local
PUSHER_HOST=127.0.0.1
PUSHER_PORT=6001
PUSHER_SCHEME=http
PUSHER_APP_CLUSTER=mt1
```

## 2) نسخ الملفات
انسخ كل الملفات من هذا الأرشيف داخل مشروعك بحسب المسارات.

## 3) تشغيل الترقيات وقاعدة البيانات
```bash
php artisan migrate
php artisan db:seed --class=ProfessionSeeder
php artisan queue:table && php artisan migrate
```

## 4) تشغيل WebSockets + السيرفر
```bash
php artisan websockets:serve
php artisan serve
```

## 5) إنشاء مسؤول
```bash
php artisan tinker
>>> $u = \App\Models\User::firstOrCreate(['email'=>'admin@example.com'], ['name'=>'Admin','password'=>bcrypt('password')]);
>>> $u->assignRole('Admin');
```

## ملاحظات
- إن كنت ستستخدم الواجهة **Vue** التي زودتك بها سابقًا، فحوّل الكنترولرز إلى **API** وأضف حماية Sanctum (أو Passport).
- Filament على `/admin`. أنشئ مستخدم Admin وادخل به.
- هذا الـ starter يغطي دورة العمل: (عميل ← طلب خدمة ← عروض مهنيين ← عقد ← تقييم) + محادثات.