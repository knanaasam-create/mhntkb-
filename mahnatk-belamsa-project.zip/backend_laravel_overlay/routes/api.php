<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\{AuthController,JobApiController,BidApiController,ContractApiController,ChatApiController,ReviewApiController};

Route::middleware('guest')->group(function(){
    Route::post('/auth/register', [AuthController::class, 'register']);
    Route::post('/auth/login', [AuthController::class, 'login']);
});

Route::middleware(['auth:sanctum'])->group(function(){
    Route::post('/auth/logout', [AuthController::class, 'logout']);

    // Jobs
    Route::get('/jobs', [JobApiController::class,'index']);
    Route::post('/jobs', [JobApiController::class,'store']);
    Route::get('/jobs/{job}', [JobApiController::class,'show']);

    // Bids
    Route::get('/jobs/{job}/bids', [BidApiController::class,'list']);
    Route::post('/jobs/{job}/bids', [BidApiController::class,'store']);

    // Contracts
    Route::post('/bids/{bid}/accept', [ContractApiController::class,'accept']);
    Route::get('/contracts/{contract}', [ContractApiController::class,'show']);

    // Reviews
    Route::post('/contracts/{contract}/review', [ReviewApiController::class,'store']);

    // Chat
    Route::post('/conversations/{conversation}/send', [ChatApiController::class,'send']);
});
