<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{JobController,BidController,ContractController,ReviewController,ChatController};

Route::middleware(['auth','verified'])->group(function(){
    // Jobs
    Route::get('/jobs', [JobController::class,'index'])->name('jobs.index');
    Route::get('/jobs/{job}', [JobController::class,'show'])->name('jobs.show');
    Route::post('/jobs', [JobController::class,'store'])->name('jobs.store');

    // Bids
    Route::get('/jobs/{job}/bids', [BidController::class,'list'])->name('bids.list');
    Route::post('/jobs/{job}/bids', [BidController::class,'store'])->name('bids.store');

    // Contracts
    Route::post('/bids/{bid}/accept', [ContractController::class,'accept'])->name('contracts.accept');

    // Reviews
    Route::post('/contracts/{contract}/review', [ReviewController::class,'store'])->name('reviews.store');

    // Chat
    Route::post('/conversations/{conversation}/send', [ChatController::class,'send'])->name('chat.send');
});
