<?php

use Illuminate\Support\Facades\Broadcast;
use App\Models\Conversation;

Broadcast::channel('conversation.{id}', function ($user, $id) {
    $c = Conversation::find($id);
    if (!$c) return false;
    return optional($c->customer)->user_id === $user->id || optional($c->professional)->user_id === $user->id;
});
