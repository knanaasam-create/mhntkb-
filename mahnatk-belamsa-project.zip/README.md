# مهنتك بلمسة — الإصدار الجاهز (Backend API + Frontend Vue + UI/UX)

هذا الأرشيف يسلّم لك كل ما تحتاجه لتشغيل النسخة الأولية (MVP):

- **backend_laravel_overlay/**: ملفات تُنسخ فوق مشروع Laravel جديد لتفعيل JSON API + Sanctum + Filament + WebSockets.
- **frontend_vue/**: مشروع Vue جاهز (Vite + Pinia + Axios) متصل بالـ API.
- **design/**: ملف Figma (placeholder) للهوية والواجهات.
- **devops/**: Docker Compose لقاعدة البيانات MySQL + Mailpit للاختبار (اختياري).
- **tools/**: مجموعة Postman لاختبار الـ API.

> ملاحظة: لا نرفق مجلّد `vendor` لأن Composer سيقوم بتثبيته محليًا لديك.

---
## تشغيل سريع (محلي)
1) أنشئ مشروع Laravel جديد:
```bash
composer create-project laravel/laravel backend
cd backend
```

2) ثبّت الحزم الأساسية:
```bash
composer require laravel/sanctum spatie/laravel-permission filament/filament:"^3.2" beyondcode/laravel-websockets
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan vendor:publish --provider="BeyondCode\LaravelWebSockets\WebSocketsServiceProvider"
php artisan migrate
```

3) انسخ محتوى **backend_laravel_overlay/** فوق مجلد مشروع Laravel (وافق على الاستبدال).

4) انسخ ملف `.env.example` من المجلد **backend_laravel_overlay/** إلى مشروعك كـ `.env` ثم حرّر القيم (قاعدة البيانات، البريد).

5) أنشئ جداول الطوابير والبثّ وشغّل الترقيات:
```bash
php artisan queue:table && php artisan migrate
```

6) Seeder للمهن:
```bash
php artisan db:seed --class=ProfessionSeeder
```

7) شغّل السيرفرات:
```bash
php artisan websockets:serve &
php artisan serve
```

8) شغّل الواجهة الأمامية:
```bash
cd ../frontend_vue
npm i
cp .env.example .env   # عدّل VITE_API_BASE إلى http://localhost:8000
npm run dev
```

9) Filament Admin على: `http://localhost:8000/admin`  
أنشئ مستخدم وأعطه دور **Admin**:
```bash
php artisan tinker
>>> $u = \App\Models\User::firstOrCreate(['email'=>'admin@example.com'], ['name'=>'Admin','password'=>bcrypt('password')]);
>>> $u->assignRole('Admin');
```

---
## ملاحظات
- الواجهة **Vue** معدّة لاستخدام المصادقة بالكوكيز عبر **Sanctum** (`withCredentials: true`).
- تأكد من إعداد **CORS** كما هو مذكور في `config/cors.php` ضمن المجلد الخلفي.
- مجموعة **Postman** موجودة في `tools/mahnatk_api.postman_collection.json` وتغطي التسجيل/الدخول/الوظائف/العروض/العقود/المحادثات.